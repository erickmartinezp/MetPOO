/*
 * Crear un app que permita registrar los datos 
de varios estudiantes y evalue si tiene derecho a beca
el est tiene tiene derecho a beca si su promedio 
es mayor a 85
 */
package practicajunio22;

/**
 *
 * @author Lab-1 Pc-2
 */
public class PracticaJunio22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
